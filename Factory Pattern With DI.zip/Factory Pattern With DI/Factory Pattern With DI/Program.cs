﻿


using Factory_Pattern_With_DI.Services.Factories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

public class Program
{
   public static void Main()
  {

        // Build Config
        var config = new ConfigurationBuilder()
            .SetBasePath(AppContext.BaseDirectory).AddJsonFile("appsettings.json",false).Build();


        // Configer Services
        var services = new ServiceCollection()
           .AddSingleton<IConfiguration>(config)
           .AddSingleton<DatabaseConnectionFactory>()
           .BuildServiceProvider();

        var factory = services.GetRequiredService<DatabaseConnectionFactory>();


        try
        {
            var connect = factory.CreateConnection(Factory_Pattern_With_DI.Enums.DatabaseType.SqlServer);
            connect.connect();
            Console.WriteLine(connect.ExecuteQuery("select * from Table"));
        }
        catch (Exception)
        {

            throw;
        }
  }

}