﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory_Pattern_With_DI.Services.Connections
{
    internal class MySqlConnection : IDatabaseConnection
    {
        private readonly string _connectionString;
        public MySqlConnection(string connectionString) {

            if (string.IsNullOrEmpty(connectionString))
                throw new ArgumentNullException("Invalied ConnectionString");

            _connectionString = connectionString;
        }

        public void connect()
        {
            Console.WriteLine("MY SQL connect");
        }

        public string ExecuteQuery(string query)
        {
            return $"query executed {query}";
        }
    }
}
