﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory_Pattern_With_DI.Services.Connections
{
    public class SqlServerConnection : IDatabaseConnection
    {

        private readonly string _connectionString;

        public SqlServerConnection(string connectionString) {

            if (string.IsNullOrEmpty(connectionString))
                throw new ArgumentNullException("Invalid Connectionstring");
                _connectionString = connectionString;
        }    

        public void connect()
        {
            Console.WriteLine("SQL connect");
        }

        public string ExecuteQuery(string query)
        {
            return $"query executed {query}";
        }
    }
}
