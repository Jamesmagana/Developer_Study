﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Factory_Pattern_With_DI.Enums;
using Factory_Pattern_With_DI.Services.Connections;
using Microsoft.Extensions.Configuration;




namespace Factory_Pattern_With_DI.Services.Factories
{
    public class DatabaseConnectionFactory
    {

        private readonly IConfiguration _config;

        public DatabaseConnectionFactory(IConfiguration config)
        {
            
            _config = config;
        }

        public IDatabaseConnection CreateConnection(DatabaseType DBType)
        {
            var connectionString = _config.GetConnectionString(DBType.ToString());

            if (string.IsNullOrEmpty(connectionString))
                throw new ArgumentException($"connectionstring for {DBType} is missing or invalid");

            return DBType switch
            {
                DatabaseType.SqlServer => new SqlServerConnection(connectionString),
                DatabaseType.MySql => new MySqlConnection(connectionString),
                DatabaseType.PostgreSql => new MySqlConnection(connectionString),
                _=> throw new ArgumentException($"Wrong DB Type")
            };
        }
    }
}
