﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lamda_and_Event_with_Delegate_demo
{
    internal class Player
    {
        public int Points { get; private set; }

        public delegate void AchievementHandler(int points);
        
        public event AchievementHandler?  AchievementUnloced;

        public async Task AddPoints(int points)
        {
            Points += points;
            Console.WriteLine($"player earned points {points}. Total earned points");
            await Task.Delay(1000);

            if (Points >= 100)
                AchievementUnloced?.Invoke(Points);
        
        }


            



    }
}
