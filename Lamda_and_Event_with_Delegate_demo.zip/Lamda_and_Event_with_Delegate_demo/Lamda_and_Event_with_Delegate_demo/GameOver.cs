﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lamda_and_Event_with_Delegate_demo
{
    internal class GameOver
    {

        public void FinalResult(int points)
        {
            Console.WriteLine($"Game Over....Player win, Player earned {points} points.");
        }
    }
}
