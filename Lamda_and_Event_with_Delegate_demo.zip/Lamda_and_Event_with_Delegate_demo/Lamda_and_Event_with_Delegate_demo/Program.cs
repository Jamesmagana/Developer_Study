﻿


using Lamda_and_Event_with_Delegate_demo;

Player player = new Player();
    GameOver gameOver = new GameOver();



player.AchievementUnloced += onAchievementUnlocked;
    player.AchievementUnloced += gameOver.FinalResult;

    await player.AddPoints(30);
    await player.AddPoints(40);
    await player.AddPoints(30);

// for memory safty
    player.AchievementUnloced -= onAchievementUnlocked;
    player.AchievementUnloced -= gameOver.FinalResult;

  

    static void onAchievementUnlocked(int point)
    {
    Console.WriteLine($"Congragulation! Player earned {point} points.");
    }


// use of Delegate use with Lemda 
//delegate int numOpartions(int x,int y);

//class Program{


//static void Main(string[] args)
//{

//        numOpartions num = (x,y) => x*y;

//        Console.WriteLine(num(2,4));
//        Console.WriteLine();
//}

//}

