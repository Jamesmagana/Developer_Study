﻿

delegate int numberofChnager(int n);


public class DelegateApp { 
    
    
    static int number =10;

    public static int AddNumber(int n)
    { 
         return number += n; 
    }
    
    public static int SubtractNumber(int n) 
    {
        return number -= n; 
    
    }

    public static int getNumber()

        { return number; }

    static void Main(String[] args)
    {

       // Create Delegate Instance 
        numberofChnager nc1 = new numberofChnager(AddNumber);
        numberofChnager nc2 = new numberofChnager(SubtractNumber);


        // Calling methodes from Delegate instance 
        nc1(4);
        Console.WriteLine(number);
        nc2(7);
        Console.WriteLine(number);
        Console.ReadKey();


    }

}